<?php
$dir               = realpath(dirname(__FILE__));
$GLOBALS['bgFull'] = '';
$crawlToken        = 418941;
include $dir . '/crawl.php';
