<?php
$docRoot = __DIR__;

require_once "$docRoot/inc/config.php";
require_once "$docRoot/inc/functions.php";
