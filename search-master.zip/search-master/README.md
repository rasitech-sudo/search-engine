search
======

An Open Source Search Engine
Completely written in PHP and uses the following PHP libraries :

1) PHPCrawler (customized)

2) SimpleHTMLDom

Called by the name "Web Search" (WS) and it has its own crawler named Dingo! which is also written in PHP. Crawler runs every minute and indexes upto 100 pages each minute.
That's 6000 pages every hour !

See Stats : http://search.subinsb.com/about/stats.php

UPDATE (2020): The site is down because I can't affort to host one, you can see the archive site here : https://web.archive.org/web/20170930165254/http://search.subinsb.com/

## SQL

This repo was made from [this tutorial](https://subinsb.com/search-engine-in-php-part-1). SQL file can be found in [Part 2](http://subinsb.com/search-engine-in-php-part-2)
